# 教师兼班主任工作台

一个面向中小学班主任 / 任课教师的日常教学管理工作台，采用前后端分离架构，覆盖**教师工作**（资源、试卷、背书管理）与**班主任工作**（学生档案、成绩分析、积分、请假、期末评价、家校沟通、座位表）两大类业务，开箱即用、一键编译部署。

![技术栈](https://img.shields.io/badge/Frontend-Vue3%20%2B%20Element%20Plus%20%2B%20Vite-blue)
![后端](https://img.shields.io/badge/Backend-Node.js%20Express%20%2B%20SQLite-green)
![部署](https://img.shields.io/badge/Deploy-Nginx%20%2B%20PM2-orange)

---

## 目录

- [功能特性](#功能特性)
- [技术架构](#技术架构)
- [项目结构](#项目结构)
- [数据库设计](#数据库设计)
- [API 接口一览](#api-接口一览)
- [快速开始（本地开发）](#快速开始本地开发)
- [一键编译打包](#一键编译打包)
- [生产部署（Nginx + PM2）](#生产部署nginx--pm2)
- [使用说明](#使用说明)
- [数据备份与运维](#数据备份与运维)
- [常见问题 FAQ](#常见问题-faq)

---

## 功能特性

### 教师工作
- **资源管理**：上传 / 下载 / 删除教学资源（PDF、Word、PPT、Excel、图片、音视频等），支持拖拽上传
- **试卷管理**：新增、删除试卷，支持录入题目内容并在线预览
- **背书管理**：批量登记背书任务，一键标记"已背 / 未背"，按科目、状态筛选

### 班主任工作
- **学生档案**：新增 / 编辑 / 删除 / 详情查看，支持 **Excel 一键导入**，可标记特殊情况（单亲、孤儿、留守等）
- **成绩分析**：Excel 导入成绩，自动生成每位学生的**平均分、最高分、考试次数及进退趋势分析**
- **积分管理**：录入加分 / 扣分（可正可负），按学生筛选，用于班级激励
- **请假管理**：登记请假、销假、删除，今日在假人数实时统计
- **期末评价**：**一键生成评价**，根据成绩与积分自动计算等级（A/B/C/D）与个性化评语，支持手动修改
- **家校沟通**：登记电话 / 微信 / 家访等沟通记录与家长反馈
- **座位表**：根据学生名单自动生成可视化座位表

### 数据看板
首页实时展示资源总数、试卷数量、今日请假、家校沟通、学生人数、待背篇目、班级总积分等关键指标，并呈现最近班级动态时间线。

---

## 技术架构

```
┌─────────────────────────────────────────────────────────┐
│                       浏览器                             │
└──────────────────────────┬──────────────────────────────┘
                           │  HTTP
     ┌─────────────────────┴─────────────────────┐
     │ （可选）Nginx  80 端口                      │ （可选）直连后端
     │  / /assets 静态 + /api /uploads 反代         │
     └─────────────────────┬─────────────────────┘
                           │
                     ┌─────▼──────┐        ┌─────────────┐
                     │ Node.js    │ 3000   │  (可选) 由后端 │
                     │ Express 后端 │<──────>│ 直接托管 dist  │
                     └─────┬──────┘        └─────────────┘
                           │
                    ┌──────▼──────┐
                    │  SQLite +    │ database.sqlite + uploads/
                    └─────────────┘
```

| 层 | 技术选型 | 说明 |
| --- | --- | --- |
| 前端 | Vue 3 + Vite + Element Plus + Vue Router + Axios | 单页应用，构建后为纯静态资源 |
| 后端 | Node.js + Express 5 | RESTful 接口，统一返回 `{ code, message, data }` |
| 数据库 | SQLite（`sqlite3` + `sqlite`） | 单文件数据库，零部署成本，首次启动自动建表 |
| 文件存储 | 本地磁盘 `backend/uploads/` | 上传的资源文件，通过 `/uploads` 访问 |
| 部署 | 单进程直连 **或** Nginx + PM2 | 见下方部署章节 |

---

## 项目结构

```
teacher_ops/
├── build.sh                  # 一键编译打包脚本
├── start.sh                  # 一键启动脚本（生产/开发模式、status、restart）
├── stop.sh                   # 一键停止脚本（后端/前端开发服务）
├── run/                      # 进程 PID 文件（运行时生成）
├── logs/                     # 运行日志（运行时生成）
├── docs/
│   └── design-spec.md        # 概要设计与详细设计文档
├── backend/                  # 后端服务
│   ├── server.js             # 服务入口（Express 应用、中间件、路由挂载）
│   ├── db.js                 # SQLite 连接与建表（9 张核心表）
│   ├── routes/
│   │   ├── teacher.js        # 教师模块：资源 / 试卷 / 背书
│   │   ├── advisor.js        # 班主任模块：学生 / 成绩 / 积分 / 请假 / 评价 / 沟通
│   │   └── stats.js          # 数据看板统计
│   ├── uploads/              # 上传文件目录（自动创建）
│   ├── database.sqlite       # 数据库文件（首次启动自动生成）
│   └── package.json
├── frontend/                 # 前端工程
│   ├── index.html
│   ├── vite.config.js        # 开发代理 / 构建配置
│   └── src/
│       ├── main.js           # 应用入口（Element Plus 中文化）
│       ├── App.vue
│       ├── api/              # Axios 封装与全部接口函数
│       ├── router/           # 路由表
│       ├── layout/           # 整体布局（左侧菜单 + 右侧主体）
│       └── views/
│           ├── dashboard/        # 数据看板
│           ├── teacher/          # 资源 / 试卷 / 背书
│           └── advisor/          # 学生 / 成绩 / 积分 / 请假 / 评价 / 沟通 / 座位
└── deploy/
    ├── nginx.conf            # Nginx 配置样例
    └── README.md             # 部署说明
```

---

## 数据库设计

SQLite 单文件数据库 `backend/database.sqlite`，共 **9 张业务表**（服务启动时自动创建）。

| 表 | 说明 | 关键字段 |
| --- | --- | --- |
| `resources` | 教学资源 | `title`、`file_path`、`type`、`upload_time` |
| `exams` | 试卷 | `title`、`type`、`content`(JSON)、`created_at` |
| `recitations` | 背书 | `student_name`、`subject`、`article`、`status`(0/1) |
| `students` | 学生档案 | `name`、`gender`、`birth`、`parent_name`、`phone`、`family_info`、`address`、`is_special`、`special_type` |
| `scores` | 成绩 | `student_id`(FK)、`subject`、`score`、`exam_name` |
| `points` | 积分 | `student_id`(FK)、`reason`、`points`、`created_at` |
| `leaves` | 请假 | `student_id`(FK)、`start_date`、`end_date`、`reason`、`status`(登记/已销假) |
| `evaluations` | 期末评价 | `student_id`(FK)、`teacher_score`、`final_grade`、`comment` |
| `communications` | 家校沟通 | `student_id`(FK)、`date`、`method`、`content`、`feedback` |

> 学生被删除时，其关联的成绩、积分、请假、评价、沟通记录会自动级联清理。

---

## API 接口一览

统一前缀 `/api/v1`，所有接口返回 `{ "code": 200, "message": "success", "data": ... }`。

### 通用
| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/health` | 健康检查 |
| GET | `/stats` | 看板统计数据与最近动态 |

### 教师工作
| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/resources` | 资源列表 |
| POST | `/resources` | 上传资源（multipart/form-data） |
| DELETE | `/resources/:id` | 删除资源 |
| GET | `/exams` | 试卷列表 |
| POST | `/exams` | 新增试卷 |
| DELETE | `/exams/:id` | 删除试卷 |
| GET | `/recitations` | 背书列表 |
| POST | `/recitations` | 登记背书 |
| PUT | `/recitations/:id` | 更新背书状态（已背/撤销） |
| DELETE | `/recitations/:id` | 删除背书 |

### 班主任工作
| 方法 | 路径 | 说明 |
| --- | --- | --- |
| GET | `/students` | 学生列表 |
| GET | `/students/:id` | 学生详情 |
| POST | `/students` | 新增学生 |
| PUT | `/students/:id` | 更新学生 |
| DELETE | `/students/:id` | 删除学生（级联清理） |
| POST | `/students/import` | Excel 一键导入学生 |
| GET | `/scores` | 成绩列表（含学生姓名） |
| POST | `/scores/import` | Excel 导入成绩 |
| GET | `/points` | 积分列表 |
| POST | `/points` | 录入积分 |
| DELETE | `/points/:id` | 删除积分 |
| GET | `/seats` | 座位表 |
| GET | `/leaves` | 请假列表 |
| POST | `/leaves` | 登记请假 / 销假 |
| DELETE | `/leaves/:id` | 删除请假 |
| GET | `/evaluations` | 评价列表 |
| POST | `/evaluations/generate` | 一键生成评价 |
| PUT | `/evaluations/:id` | 修改评价 |
| GET | `/communications` | 沟通记录 |
| POST | `/communications` | 新增沟通 |
| DELETE | `/communications/:id` | 删除沟通 |

---

## 快速开始（本地开发）

### 环境要求
- Node.js ≥ 18（推荐 20 及以上）
- npm ≥ 9

### 1. 启动后端

```bash
cd backend
npm install
node server.js
# 或 npm start
```

看到如下输出即启动成功：
```
Database initialized and tables created/verified.
Server is running on http://localhost:3000
API prefix: /api/v1
```

验证：`curl http://localhost:3000/api/v1/health` → `{"code":200,...}`

### 2. 启动前端（开发模式）

```bash
cd frontend
npm install
npm run dev
```

浏览器访问 `http://localhost:5173`。开发模式下 `/api` 与 `/uploads` 请求会被 Vite 代理到后端 `http://localhost:3000`。

> 提示：如需修改后端端口，可设置环境变量 `PORT`（如 `PORT=8080 node server.js`），并同步修改 `frontend/vite.config.js` 中的代理目标。

### 3. 直接访问（无需 Nginx）

后端已内置"托管前端构建产物"能力：只要 `frontend/dist` 存在（执行过 `./build.sh`），后端会同时服务前端页面与 API，访问 `http://localhost:3000` 即为完整系统，无需额外安装 Nginx。

```bash
./build.sh       # 构建前端 (生成 frontend/dist)
./start.sh       # 启动后端, 直接访问 http://localhost:3000
```

> 此时前端 API 请求为同源（`/api/v1`），资源下载（`/uploads`）也由后端直接处理，单进程即可运行整个系统。

### 4. 一键启动 / 停止（推荐）

项目根目录提供了 `start.sh` 与 `stop.sh`，可一键管理服务进程，无需手动开多个终端：

```bash
# 启动
./start.sh            # 生产模式：仅启动后端（前端由 Nginx 托管）
./start.sh --dev      # 开发模式：后端 + 前端 Vite 开发服务
./start.sh status     # 查看运行状态
./start.sh restart    # 重启已启动的服务

# 停止
./stop.sh             # 停止全部（后端 + 前端开发服务）
./stop.sh backend     # 仅停止后端
./stop.sh frontend    # 仅停止前端开发服务
```

服务说明：
- 进程 PID 记录在 `run/` 目录，日志输出到 `logs/`（`backend.log`、`frontend.log`）。
- 脚本已内置 Apple Silicon（M 系列）下 Rosetta 架构兼容处理，并采用**进程组**管理，`stop.sh` 可确保连同子进程一并结束，不留孤儿进程。
- 开发模式下执行 `restart` 会同时重启后端与前端；生产模式仅重启后端。

---

## 一键编译打包

在项目根目录执行：

```bash
chmod +x build.sh
./build.sh
```

脚本会自动完成：
1. 安装前端依赖（已存在则跳过）
2. 构建前端生产包 → `frontend/dist/`
3. 安装后端依赖（已存在则跳过）
4. 生成部署配置样例 `deploy/nginx/nginx.conf.example`

> 脚本已内置 Apple Silicon（M 系列芯片）macOS 下 Rosetta 架构兼容处理，保证原生绑定模块加载一致，可重复执行、构建稳定。

---

## 生产部署（Nginx + PM2）

> **两种方式任选其一**：
> - **方式 A（推荐，最简单）**：后端直接托管前端，只需一个 Node 进程。见下文"零 Nginx 部署"。
> - **方式 B**：Nginx 托管前端静态资源 + 反向代理 `/api`、`/uploads`。适合需要 80 端口直出、域名、静态缓存等场景。

### 方式 A：零 Nginx 部署（单进程）

```bash
# 服务器上执行
./build.sh                        # 构建前端(生成 frontend/dist)
cd backend && npm install         # 安装后端依赖
pm2 start server.js --name teacher-ops   # 或直接 node server.js
```

访问 `http://服务器IP:3000` 即为完整系统。

### 方式 B：Nginx + 后端（经典部署）

### 1. 部署后端

```bash
cd backend
# 方式一：直接运行（简单场景）
npm start

# 方式二：PM2 守护进程（推荐，崩溃自动重启）
npm install -g pm2
pm2 start server.js --name teacher-ops
pm2 save
pm2 startup          # 按提示执行输出的命令以开机自启
```

### 2. 部署前端 + Nginx

```bash
# 将构建产物拷贝到服务器
scp -r frontend/dist/* user@server:/opt/teacher_ops/frontend/dist/

# 使用提供的 Nginx 配置样例
sudo cp deploy/nginx.conf /etc/nginx/conf.d/teacher_ops.conf
# 按需修改 server_name 与 root 路径
sudo nginx -t
sudo systemctl reload nginx
```

`deploy/nginx.conf` 关键配置（可直接使用）：

```nginx
server {
    listen 80;
    root  /opt/teacher_ops/frontend/dist;
    index index.html;

    client_max_body_size 100m;          # 允许大文件上传

    location /assets/ {                 # 静态资源长缓存
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    location / {                        # Vue Router history 模式回退
        try_files $uri $uri/ /index.html;
    }

    location /api/ {                    # 后端接口反向代理
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /uploads/ {                # 上传文件预览/下载
        proxy_pass http://127.0.0.1:3000;
    }
}
```

### 3. 验证

```bash
curl http://127.0.0.1:3000/api/v1/health   # 后端健康检查
curl http://your-domain/api/v1/health      # 通过 Nginx 访问
```

浏览器访问 `http://your-domain` 即可使用。

---

## 使用说明

1. **录入学生**：进入「班主任工作 → 学生档案」，点击"新增学生"逐条录入，或点击"Excel 导入"批量导入。Excel 表头格式：
   - 学生：`name`(姓名)、`gender`(性别)、`birth`(出生年月)、`parent_name`(家长姓名)、`phone`(联系电话)、`family_info`(家庭情况)、`address`(地址)、`special_type`(特殊情况)
   - 成绩：`student_id`(学号)、`subject`(科目)、`score`(成绩)、`exam_name`(考试名称)
2. **日常教学**：上传资源、录入试卷、登记背书任务，并跟踪背书完成情况。
3. **班级管理**：录入成绩后自动生成进退分析；发放积分激励学生；登记与销假；期末一键生成评价并可按需微调；每次与家长沟通后登记记录。
4. **座位表**：录入学生后自动生成，刷新或重新生成即可。
5. **数据看板**：首页实时反映各模块核心指标与最新动态。

---

## 数据备份与运维

- **备份数据**：直接备份 `backend/database.sqlite` 与 `backend/uploads/` 两个文件即可，复制到新机器后覆盖即可恢复全部数据。
- **查看日志**：`pm2 logs teacher-ops`
- **重启服务**：`pm2 restart teacher-ops`
- **健康检查**：`curl http://127.0.0.1:3000/api/v1/health`
- **升级前端**：重新执行 `./build.sh`，将新的 `frontend/dist` 覆盖到 Nginx 静态目录后 `sudo systemctl reload nginx`。

---

## 常见问题 FAQ

**Q1：部署到服务器后页面 404 或刷新后白屏？**
Nginx 需要配置 `try_files $uri $uri/ /index.html;`（已包含在样例中）。若未生效，请确认 `location /` 配置正确，并清空浏览器缓存。

**Q2：上传大文件失败？**
在 Nginx 中增加 `client_max_body_size 100m;`（样例已包含），并确认后端 `multer` 未设置过小的文件大小限制。

**Q3：接口请求报 404？**
请确认 Nginx 已将 `/api/` 反向代理到后端 3000 端口，且后端服务正常运行。

**Q4：如何修改默认端口？**
后端：`PORT=8080 node server.js`；前端开发代理：修改 `frontend/vite.config.js` 中 proxy 的 target；生产环境：修改 Nginx 的 `proxy_pass`。

**Q5：数据库能直接修改吗？**
可以。SQLite 单文件，可用 `sqlite3` 命令行或 SQLite 图形工具直接操作，但建议通过页面操作以保证关联数据一致性（如学生删除的级联清理）。

**Q6：部署时前端依赖在安装阶段报架构错误（macOS）？**
请使用 `./build.sh` 一键构建（已内置架构兼容处理），或确认使用原生 arm64 架构的 Node 运行 `npm run build`。

---

## 许可

本项目用于日常教学管理场景，代码可自由使用与二次开发。
