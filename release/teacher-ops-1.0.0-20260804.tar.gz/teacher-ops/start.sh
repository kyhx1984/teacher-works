#!/usr/bin/env bash
###############################################################################
# 一键启动脚本
#
# 用法:
#   ./start.sh           启动后端服务(生产模式, 前端由 Nginx 托管)
#   ./start.sh --dev     启动后端 + 前端 Vite 开发服务(本地开发)
#   ./start.sh status    查看运行状态
#   ./start.sh restart   重启已启动的服务
#
# 说明:
#   - 后端服务运行于 3000 端口, 日志: logs/backend.log
#   - 前端开发服务运行于 5173 端口, 日志: logs/frontend.log
#   - 进程 PID 记录在 run/ 目录, 使用 ./stop.sh 一键停止
###############################################################################

set -e

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUN_DIR="$ROOT_DIR/run"
LOG_DIR="$ROOT_DIR/logs"
BACKEND_DIR="$ROOT_DIR/backend"
FRONTEND_DIR="$ROOT_DIR/frontend"
BACKEND_PID="$RUN_DIR/backend.pid"
FRONTEND_PID="$RUN_DIR/frontend.pid"
PORT="${PORT:-3000}"
FRONTEND_PORT="${FRONTEND_PORT:-5173}"

mkdir -p "$RUN_DIR" "$LOG_DIR"

# 启用作业控制, 使后台进程独立成组(PGID)。
# 配合 `arch -arm64` 在 Rosetta 环境下 fork 出的真实 node 子进程,
# 可通过 `kill -- -PID` 一次性结束整个进程组, 避免遗留孤儿进程。
set -m

# Apple Silicon (M 系列芯片) 下, bash 执行的 node 可能走 Rosetta(x64) 兜底,
# 导致 sqlite3/rollup 等原生绑定加载失败。这里统一强制使用原生 arm64 架构。
run_native() {
  local is_apple_silicon=0
  if [ "$(uname -s)" = "Darwin" ] && [ "$(sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ]; then
    is_apple_silicon=1
  fi
  if [ "$is_apple_silicon" = "1" ]; then
    arch -arm64 "$@"
  else
    "$@"
  fi
}

is_running() {
  local pid_file="$1"
  [ -f "$pid_file" ] || return 1
  local pid
  pid="$(cat "$pid_file" 2>/dev/null || true)"
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}

wait_ready() {
  local url="$1"
  local retries=30
  for _ in $(seq 1 "$retries"); do
    if curl -s -o /dev/null --max-time 2 "$url"; then
      return 0
    fi
    sleep 1
  done
  return 1
}

start_backend() {
  if is_running "$BACKEND_PID"; then
    echo "  后端已在运行 (PID $(cat "$BACKEND_PID"))"
    return 0
  fi

  # 确保上传目录存在
  mkdir -p "$BACKEND_DIR/uploads"

  # 便携部署包不含 node_modules, 首次启动时自动安装
  if [ ! -d "$BACKEND_DIR/node_modules" ]; then
    echo "  后端依赖未安装, 正在安装(首次启动自动执行, 请保持网络畅通)..."
    cd "$BACKEND_DIR"
    run_native npm install --registry=https://registry.npmjs.org
  fi

  echo "  正在启动后端服务..."
  cd "$BACKEND_DIR"
  run_native node server.js > "$LOG_DIR/backend.log" 2>&1 &
  echo $! > "$BACKEND_PID"

  if wait_ready "http://127.0.0.1:$PORT/api/v1/health"; then
    echo "  后端服务启动成功 -> http://localhost:$PORT  (PID $(cat "$BACKEND_PID"))"
  else
    echo "  [警告] 后端健康检查未通过, 请查看日志: logs/backend.log"
    echo "  ---- 日志尾部 ----"
    tail -n 20 "$LOG_DIR/backend.log" 2>/dev/null || true
    return 1
  fi
}

start_frontend() {
  if is_running "$FRONTEND_PID"; then
    echo "  前端开发服务已在运行 (PID $(cat "$FRONTEND_PID"))"
    return 0
  fi

  echo "  正在启动前端开发服务..."
  cd "$FRONTEND_DIR"
  if [ ! -d "node_modules" ]; then
    echo "  前端依赖未安装, 正在安装..."
    run_native npm install --registry=https://registry.npmjs.org
  fi
  run_native node node_modules/vite/bin/vite.js --port "$FRONTEND_PORT" > "$LOG_DIR/frontend.log" 2>&1 &
  echo $! > "$FRONTEND_PID"

  sleep 3
  if is_running "$FRONTEND_PID"; then
    echo "  前端开发服务启动成功 -> http://localhost:$FRONTEND_PORT  (PID $(cat "$FRONTEND_PID"))"
  else
    echo "  [警告] 前端开发服务启动失败, 请查看日志: logs/frontend.log"
    tail -n 20 "$LOG_DIR/frontend.log" 2>/dev/null || true
    return 1
  fi
}

stop_all() {
  "$ROOT_DIR/stop.sh"
}

show_status() {
  echo "== 服务状态 =="
  if is_running "$BACKEND_PID"; then
    echo "  [运行中] 后端服务 (PID $(cat "$BACKEND_PID"))  http://localhost:$PORT"
  else
    echo "  [已停止] 后端服务"
  fi
  if is_running "$FRONTEND_PID"; then
    echo "  [运行中] 前端开发服务 (PID $(cat "$FRONTEND_PID"))  http://localhost:$FRONTEND_PORT"
  else
    echo "  [已停止] 前端开发服务"
  fi
}

MODE="${1:-prod}"
case "$MODE" in
  status|-s)
    show_status
    ;;
  restart)
    echo "== 正在重启 =="
    stop_all
    echo ""
    echo "== 重新启动 =="
    start_backend
    if [ -f "$RUN_DIR/.dev" ]; then
      start_frontend
    fi
    ;;
  --dev|dev|-d)
    echo "== 开发模式启动 =="
    touch "$RUN_DIR/.dev"
    start_backend
    start_frontend
    echo ""
    echo "提示: 浏览器访问 http://localhost:$FRONTEND_PORT"
    ;;
  prod|-p)
    rm -f "$RUN_DIR/.dev"
    echo "== 生产模式启动 =="
    start_backend
    echo ""
    if [ -f "$FRONTEND_DIR/dist/index.html" ]; then
      echo "提示: 后端已托管前端页面, 请直接访问 http://localhost:$PORT"
    else
      echo "提示: 未检测到前端构建产物, 请先执行 ./build.sh 后再访问;"
      echo "      或使用 ./start.sh --dev 启动开发服务。"
    fi
    ;;
  *)
    echo "用法: $0 [--dev | status | restart]"
    exit 1
    ;;
esac
